/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gradingsystem;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JTable;

/**
 *
 * @author User
 */
public class Course {
    
    // Declaration of the course's attributes
    String name;
    Integer units;
    String instructor;
    Boolean includedInGPA;
    JTable courseTable;
    
    // Declaration of ArrayList containing students enrolled in the course
    ArrayList<String> studentList;
    
    // Declaration of HashMap containing studentName:studentNumber key pairs
    HashMap<String, Integer> studentNameAndNumber;
    HashMap<Integer, String> studentNumberAndName;
    
    // Declaration of students' records for prelim grading period
    HashMap<String, Integer> prelimAttendanceScore;
    HashMap<String, Integer> prelimAttendanceHps;
    HashMap<String, Double> prelimAttendancePercentage;
    
    HashMap<String, Integer> prelimQuizScore;
    HashMap<String, Integer> prelimQuizHps;
    HashMap<String, Double> prelimQuizPercentage;
    
    HashMap<String, Integer> prelimPTScore;
    HashMap<String, Integer> prelimPTHps;
    HashMap<String, Double> prelimPTPercentage;
    
    HashMap<String, Integer> prelimExamScore;
    HashMap<String, Integer> prelimExamHps;
    HashMap<String, Double> prelimExamPercentage;
    
    HashMap<String, Double> prelimGrade;
    
    // Declaration of the HashMap containing the equivalent value of each student's prelimGrade to their course's standing
    HashMap<String, Double> prelimStanding;
    
    // Declaration of students' records for midterm grading period
    HashMap<String, Integer> midtermAttendanceScore;
    HashMap<String, Integer> midtermAttendanceHps;
    HashMap<String, Double> midtermAttendancePercentage;
    
    HashMap<String, Integer> midtermQuizScore;
    HashMap<String, Integer> midtermQuizHps;
    HashMap<String, Double> midtermQuizPercentage;
    
    HashMap<String, Integer> midtermPTScore;
    HashMap<String, Integer> midtermPTHps;
    HashMap<String, Double> midtermPTPercentage;
    
    HashMap<String, Integer> midtermExamScore;
    HashMap<String, Integer> midtermExamHps;
    HashMap<String, Double> midtermExamPercentage;
    
    HashMap<String, Double> midtermGrade;
    
    // Declaration of the HashMap containing the equivalent value of each student's midtermGrade to their course's standing
    HashMap<String, Double> midtermStanding;
    
    // Declaration of students' records for finals grading period    
    HashMap<String, Integer> finalsAttendanceScore;
    HashMap<String, Integer> finalsAttendanceHps;
    HashMap<String, Double> finalsAttendancePercentage;
    
    HashMap<String, Integer> finalsQuizScore;
    HashMap<String, Integer> finalsQuizHps;
    HashMap<String, Double> finalsQuizPercentage;
    
    HashMap<String, Integer> finalsPTScore;
    HashMap<String, Integer> finalsPTHps;
    HashMap<String, Double> finalsPTPercentage;
    
    HashMap<String, Integer> finalsExamScore;
    HashMap<String, Integer> finalsExamHps;
    HashMap<String, Double> finalsExamPercentage;
    
    HashMap<String, Double> finalsGrade;
    
    // Declaration of the HashMap containing the equivalent value of each student's finalsGrade to their course's standing
    HashMap<String, Double> finalsStanding;
    
    // Declaration of the HashMap containing the total standing of each student in the course
    HashMap<String, Double> totalStanding;
    
    // Declaration of the lists containing the records for convenient iteration
    ArrayList<HashMap<String, Double>> stringDoubleListForIteration;
    ArrayList<HashMap<String, Integer>> stringIntegerListForIteration;
 
    Course(String name, Integer units, String instructor, Boolean includedInGPA, JTable table) {
        
        // Instantiation of the course's attributes
        this.name = name;
        this.units = units;
        this.instructor = instructor;
        this.includedInGPA = includedInGPA;
        this.courseTable = table;
        
        // Instantiation of the list containing the students enrolled in the course
        this.studentList = new ArrayList<String>();
        
        // Instantiation of the HashMaps containing the student's name and number
        this.studentNameAndNumber = new HashMap<String, Integer>();
        this.studentNumberAndName = new HashMap<Integer, String>();
        
        // Instantiation of the HashMaps containing each student's grades for prelim
        this.prelimAttendanceScore = new HashMap<String, Integer>();
        this.prelimAttendanceHps = new HashMap<String, Integer>();
        this.prelimAttendancePercentage = new HashMap<String, Double>();
        
        this.prelimQuizScore = new HashMap<String, Integer>();
        this.prelimQuizHps = new HashMap<String, Integer>();
        this.prelimQuizPercentage = new HashMap<String, Double>();
        
        this.prelimPTScore = new HashMap<String, Integer>();
        this.prelimPTHps = new HashMap<String, Integer>();
        this.prelimPTPercentage = new HashMap<String, Double>();
        
        this.prelimExamScore = new HashMap<String, Integer>();
        this.prelimExamHps = new HashMap<String, Integer>();
        this.prelimExamPercentage = new HashMap<String, Double>();
        
        this.prelimGrade = new HashMap<String, Double>();
        
        // Instantiation of the HashMap containing the equivalent value of each student's prelimGrade to their course's standing
        this.prelimStanding = new HashMap<String, Double>();
        
        // Instantiation of the HashMaps containing each student's grades for midterm      
        this.midtermAttendanceScore = new HashMap<String, Integer>();
        this.midtermAttendanceHps = new HashMap<String, Integer>();
        this.midtermAttendancePercentage = new HashMap<String, Double>();
        
        this.midtermQuizScore = new HashMap<String, Integer>();
        this.midtermQuizHps = new HashMap<String, Integer>();
        this.midtermQuizPercentage = new HashMap<String, Double>();
        
        this.midtermPTScore = new HashMap<String, Integer>();
        this.midtermPTHps = new HashMap<String, Integer>();
        this.midtermPTPercentage = new HashMap<String, Double>();
        
        this.midtermExamScore = new HashMap<String, Integer>();
        this.midtermExamHps = new HashMap<String, Integer>();
        this.midtermExamPercentage = new HashMap<String, Double>();
        
        this.midtermGrade = new HashMap<String, Double>();
        
        // Instantiation of the HashMap containing the equivalent value of each student's midtermGrade to their course's standing
        this.midtermStanding = new HashMap<String, Double>();
        
        // Instantiation of the HashMaps containing each student's grades for finals 
        this.finalsAttendanceScore = new HashMap<String, Integer>();
        this.finalsAttendanceHps = new HashMap<String, Integer>();
        this.finalsAttendancePercentage = new HashMap<String, Double>();
        
        this.finalsQuizScore = new HashMap<String, Integer>();
        this.finalsQuizHps = new HashMap<String, Integer>();
        this.finalsQuizPercentage = new HashMap<String, Double>();
        
        this.finalsPTScore = new HashMap<String, Integer>();
        this.finalsPTHps = new HashMap<String, Integer>();
        this.finalsPTPercentage = new HashMap<String, Double>();
        
        this.finalsExamScore = new HashMap<String, Integer>();
        this.finalsExamHps = new HashMap<String, Integer>();
        this.finalsExamPercentage = new HashMap<String, Double>();
        
        this.finalsGrade = new HashMap<String, Double>();
        
        // Instantiation of the HashMap containing the equivalent value of each student's finalsGrade to their course's standing
        this.finalsStanding = new HashMap<String, Double>();
        
        // Instantiation of the HashMap containing the student's name and their course standing
        this.totalStanding = new HashMap<String, Double>();
        
        // Instantiation of list of records for convenience of iteration
        this.stringDoubleListForIteration = new ArrayList<HashMap<String, Double>>();
        this.stringIntegerListForIteration = new ArrayList<HashMap<String, Integer>>();
        
        // Adding the HashMap records to the list they are compatible with for convenience of iteration
        this.stringDoubleListForIteration.add(this.prelimGrade);
        this.stringDoubleListForIteration.add(this.prelimAttendancePercentage);
        this.stringDoubleListForIteration.add(this.prelimQuizPercentage);
        this.stringDoubleListForIteration.add(this.prelimPTPercentage);
        this.stringDoubleListForIteration.add(this.prelimExamPercentage);
        this.stringDoubleListForIteration.add(this.prelimStanding);
        this.stringDoubleListForIteration.add(this.midtermGrade);
        this.stringDoubleListForIteration.add(this.midtermAttendancePercentage);
        this.stringDoubleListForIteration.add(this.midtermQuizPercentage);
        this.stringDoubleListForIteration.add(this.midtermPTPercentage);
        this.stringDoubleListForIteration.add(this.midtermExamPercentage);
        this.stringDoubleListForIteration.add(this.midtermStanding);
        this.stringDoubleListForIteration.add(this.finalsGrade);
        this.stringDoubleListForIteration.add(this.finalsAttendancePercentage);
        this.stringDoubleListForIteration.add(this.finalsQuizPercentage);
        this.stringDoubleListForIteration.add(this.finalsPTPercentage);
        this.stringDoubleListForIteration.add(this.finalsExamPercentage);
        this.stringDoubleListForIteration.add(this.finalsStanding);
        this.stringDoubleListForIteration.add(this.totalStanding);
                     
        this.stringIntegerListForIteration.add(this.prelimAttendanceScore);
        this.stringIntegerListForIteration.add(this.prelimAttendanceHps);
        this.stringIntegerListForIteration.add(this.prelimQuizScore);
        this.stringIntegerListForIteration.add(this.prelimQuizHps);        
        this.stringIntegerListForIteration.add(this.prelimPTScore);
        this.stringIntegerListForIteration.add(this.prelimPTHps);
        this.stringIntegerListForIteration.add(this.prelimExamScore);
        this.stringIntegerListForIteration.add(this.prelimExamHps);
        this.stringIntegerListForIteration.add(this.midtermAttendanceScore);
        this.stringIntegerListForIteration.add(this.midtermAttendanceHps);
        this.stringIntegerListForIteration.add(this.midtermQuizScore);
        this.stringIntegerListForIteration.add(this.midtermQuizHps);        
        this.stringIntegerListForIteration.add(this.midtermPTScore);
        this.stringIntegerListForIteration.add(this.midtermPTHps);
        this.stringIntegerListForIteration.add(this.midtermExamScore);
        this.stringIntegerListForIteration.add(this.midtermExamHps);
        this.stringIntegerListForIteration.add(this.finalsAttendanceScore);
        this.stringIntegerListForIteration.add(this.finalsAttendanceHps);
        this.stringIntegerListForIteration.add(this.finalsQuizScore);
        this.stringIntegerListForIteration.add(this.finalsQuizHps);        
        this.stringIntegerListForIteration.add(this.finalsPTScore);
        this.stringIntegerListForIteration.add(this.finalsPTHps);
        this.stringIntegerListForIteration.add(this.finalsExamScore);
        this.stringIntegerListForIteration.add(this.finalsExamHps);
    }
    
    // Method to enroll a student to the course
    public void enrollStudent(String studentName) {
        this.studentList.add(studentName);   
    }
    
    // Method to compute a student's grade for a grading period
    public Double computeGrade(Double attendanceScore, Double attendanceTotal,
            Double ptScore, Double ptTotal,
            Double quizScore, Double quizTotal,
            Double examScore, Double examTotal) {
        Double grade = ((attendanceScore/attendanceTotal) * 0.10
                + (ptScore/ptTotal) * 0.20
                + (quizScore/quizTotal) * 0.20
                + (examScore/examTotal) * 0.50)*100;
        return grade;
    }
    
    // Method to encode a student's grades to the prelim records
    public void encodePrelimGrades(String studentName, 
            Integer attendanceScore, Integer attendanceHps, Double attendancePercentage,
            Integer quizScore, Integer quizHps, Double quizPercentage,
            Integer ptScore, Integer ptHps, Double ptPercentage,
            Integer examScore, Integer examHps, Double examPercentage,
            Double prelimGrade) {
        
        this.prelimAttendanceScore.replace(studentName, attendanceScore);
        this.prelimAttendanceHps.replace(studentName, attendanceHps);
        this.prelimAttendancePercentage.replace(studentName, attendancePercentage);
        
        this.prelimQuizScore.replace(studentName, quizScore);
        this.prelimQuizHps.replace(studentName, quizHps);
        this.prelimQuizPercentage.replace(studentName, quizPercentage);
        
        this.prelimPTScore.replace(studentName, ptScore);
        this.prelimPTHps.replace(studentName, ptHps);
        this.prelimPTPercentage.replace(studentName, ptPercentage);
        
        this.prelimExamScore.replace(studentName, examScore);
        this.prelimExamHps.replace(studentName, examHps);
        this.prelimExamPercentage.replace(studentName, examPercentage);
        
        this.prelimGrade.replace(studentName, prelimGrade);
        this.prelimStanding.replace(studentName, prelimGrade*0.30);
        
        // Update the student's course standing
        this.totalStanding.replace(studentName, this.totalStanding.get(studentName)+this.prelimStanding.get(studentName));
    }
    
    // Method to encode a student's grades to the midterm records
    public void encodeMidtermGrades(String studentName, 
            Integer attendanceScore, Integer attendanceHps, Double attendancePercentage,
            Integer quizScore, Integer quizHps, Double quizPercentage,
            Integer ptScore, Integer ptHps, Double ptPercentage,
            Integer examScore, Integer examHps, Double examPercentage,
            Double midtermGrade) {
        
        this.midtermAttendanceScore.replace(studentName, attendanceScore);
        this.midtermAttendanceHps.replace(studentName, attendanceHps);
        this.midtermAttendancePercentage.replace(studentName, attendancePercentage);
        
        this.midtermQuizScore.replace(studentName, quizScore);
        this.midtermQuizHps.replace(studentName, quizHps);
        this.midtermQuizPercentage.replace(studentName, quizPercentage);
        
        this.midtermPTScore.replace(studentName, ptScore);
        this.midtermPTHps.replace(studentName, ptHps);
        this.midtermPTPercentage.replace(studentName, ptPercentage);
        
        this.midtermExamScore.replace(studentName, examScore);
        this.midtermExamHps.replace(studentName, examHps);
        this.midtermExamPercentage.replace(studentName, examPercentage);
        
        this.midtermGrade.replace(studentName, midtermGrade);
        this.midtermStanding.replace(studentName, midtermGrade*0.30);

        // Update the student's course standing        
        this.totalStanding.replace(studentName, this.totalStanding.get(studentName)+this.midtermStanding.get(studentName));
    }
    
    // Method to encode a student's grades to the finals records
    public void encodeFinalsGrades(String studentName, 
            Integer attendanceScore, Integer attendanceHps, Double attendancePercentage,
            Integer quizScore, Integer quizHps, Double quizPercentage,
            Integer ptScore, Integer ptHps, Double ptPercentage,
            Integer examScore, Integer examHps, Double examPercentage,
            Double finalsGrade) {
        
        this.finalsAttendanceScore.replace(studentName, attendanceScore);
        this.finalsAttendanceHps.replace(studentName, attendanceHps);
        this.finalsAttendancePercentage.replace(studentName, attendancePercentage);
        
        this.finalsQuizScore.replace(studentName, quizScore);
        this.finalsQuizHps.replace(studentName, quizHps);
        this.finalsQuizPercentage.replace(studentName, quizPercentage);
        
        this.finalsPTScore.replace(studentName, ptScore);
        this.finalsPTHps.replace(studentName, ptHps);
        this.finalsPTPercentage.replace(studentName, ptPercentage);
        
        this.finalsExamScore.replace(studentName, examScore);
        this.finalsExamHps.replace(studentName, examHps);
        this.finalsExamPercentage.replace(studentName, examPercentage);
        
        this.finalsGrade.replace(studentName, finalsGrade);
        this.finalsStanding.replace(studentName, finalsGrade*0.40);
        
        // Update the student's course standing 
        this.totalStanding.replace(studentName, this.totalStanding.get(studentName)+this.finalsStanding.get(studentName));
    }
    
    // Method to remove a student's prelim grade from the prelim records
    public void removePrelimGrades(String studentName) {
        
        // Updates the student's course standing before resetting the student's prelim standing
        this.totalStanding.replace(studentName, this.totalStanding.get(studentName)-this.prelimStanding.get(studentName));
        
        // Resets the student's prelim grades
        this.prelimAttendanceScore.replace(studentName, 0);
        this.prelimAttendanceHps.replace(studentName, 0);
        this.prelimAttendancePercentage.replace(studentName, 0.0);
        
        this.prelimQuizScore.replace(studentName, 0);
        this.prelimQuizHps.replace(studentName, 0);
        this.prelimQuizPercentage.replace(studentName, 0.0);
        
        this.prelimPTScore.replace(studentName, 0);
        this.prelimPTHps.replace(studentName, 0);
        this.prelimPTPercentage.replace(studentName, 0.0);
        
        this.prelimExamScore.replace(studentName, 0);
        this.prelimExamHps.replace(studentName, 0);
        this.prelimExamPercentage.replace(studentName, 0.0);
        
        this.prelimGrade.replace(studentName, 0.0);
        this.prelimStanding.replace(studentName, 0.0);
        
    }
    
    // Method to remove a student's midterm grade from the midterm records
    public void removeMidtermGrades(String studentName) {
        
        // Updates the student's course standing before resetting the student's midterm standing        
        this.totalStanding.replace(studentName, this.totalStanding.get(studentName)-this.midtermStanding.get(studentName));

        // Resets the student's midterm grades
        this.midtermAttendanceScore.replace(studentName, 0);
        this.midtermAttendanceHps.replace(studentName, 0);
        this.midtermAttendancePercentage.replace(studentName, 0.0);
        
        this.midtermQuizScore.replace(studentName, 0);
        this.midtermQuizHps.replace(studentName, 0);
        this.midtermQuizPercentage.replace(studentName, 0.0);
        
        this.midtermPTScore.replace(studentName, 0);
        this.midtermPTHps.replace(studentName, 0);
        this.midtermPTPercentage.replace(studentName, 0.0);
        
        this.midtermExamScore.replace(studentName, 0);
        this.midtermExamHps.replace(studentName, 0);
        this.midtermExamPercentage.replace(studentName, 0.0);
        
        this.midtermGrade.replace(studentName, 0.0);
        this.midtermStanding.replace(studentName, 0.0);
    }
    
    // Method to remove a student's finals grade from the finals records
    public void removeFinalsGrades(String studentName) {
        
        // Updates the student's course standing before resetting the student's finals standing   
        this.totalStanding.replace(studentName, this.totalStanding.get(studentName)-this.finalsStanding.get(studentName));
        
        // Resets the student's finals grades        
        this.finalsAttendanceScore.replace(studentName, 0);
        this.finalsAttendanceHps.replace(studentName, 0);
        this.finalsAttendancePercentage.replace(studentName, 0.0);
        
        this.finalsQuizScore.replace(studentName, 0);
        this.finalsQuizHps.replace(studentName, 0);
        this.finalsQuizPercentage.replace(studentName, 0.0);
        
        this.finalsPTScore.replace(studentName, 0);
        this.finalsPTHps.replace(studentName, 0);
        this.finalsPTPercentage.replace(studentName, 0.0);
        
        this.finalsExamScore.replace(studentName, 0);
        this.finalsExamHps.replace(studentName, 0);
        this.finalsExamPercentage.replace(studentName, 0.0);
        
        this.finalsGrade.replace(studentName, 0.0);
        this.finalsStanding.replace(studentName, 0.0);
    }
}
