
package com.mycompany.gradingsystem;

/**
 * Members:
 * Cinco, Iean Mike C.
 * Dueñas, Kyla Mae A. 
 * Gelvero, Ma. Sophia D.
 * Padua, Cedie James A.
 * Vidad, John Markdyl B. 
 */

/**
 *
 * Class containing the main method
 */
public class GradingSystem {

    public static void main(String[] args) {
        
        // Simple indication that the code compiled properly
        System.out.println("Hello World!");
        
        // Create an instance of the Main frame and show it on the screen
        new Main().setVisible(true);
        
        /**
         * Log in Credentials
         * Username: engr_cimacio
         * Password: sanamakapasa
         */
    }
}
