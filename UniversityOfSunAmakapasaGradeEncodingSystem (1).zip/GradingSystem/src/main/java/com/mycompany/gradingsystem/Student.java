/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gradingsystem;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.table.DefaultTableModel;

/**
 *
 * Class containing the representation of a student
 */


public class Student {
    
    // Declaration of student attributes
    String name;
    Integer studentNumber;
    Section section;
    
    // Declaration of ArrayList containing the courses where the student is enrolled     
    ArrayList<Course> enrolledCourses;
    
    // Declaration of the integer representing the current unit load of the student
    Integer totalUnitsForGPA;
    
    // Declaration of course's DefaultTableModel
    DefaultTableModel courseDtm;
    
    Student(String name, Integer studentNumber, Section section) {
        
        // Initialization of the student attributes
        this.name = name;
        this.studentNumber = studentNumber;
        this.section = section;
        
        // Adding the new student to the section's roster
        section.studentList.add(name);
        section.studentNumList.add(studentNumber);
        
        // Create an initial GWA record of the student in the section's list 
        section.nameAndGwa.put(name, 0.0);
        
        // Initialization of the student's list of the courses
        enrolledCourses = new ArrayList<Course>();
        
        // Initialization of the student's total units for GPA
        this.totalUnitsForGPA = 0;
        
        // Iterate through each courses within the section
        for (Course course: section.courseList) {
            
            // Enroll the new student to each course
            this.enrollToCourse(course);
            
            // Add each course's units to the student's total units
            if (course.includedInGPA) {
                this.totalUnitsForGPA += course.units;
            }

            // Add the student's name and number to each courses
            course.enrollStudent(name);
            course.studentNameAndNumber.put(this.name, this.studentNumber);
            course.studentNumberAndName.put(this.studentNumber, this.name);
            
            // Create an initial record of the student for each grading period for each course
            for (HashMap<String, Double> record: course.stringDoubleListForIteration) {
                record.put(name, 0.0);
            }
            for (HashMap<String, Integer> record: course.stringIntegerListForIteration) {
                record.put(name, 0);
            }

            // Conversion of each course's table to a DefaultTableModel
            this.courseDtm = (DefaultTableModel) course.courseTable.getModel();
            
            // Display the student's name, number, prelim grade, midterm grade, finals grade, and standing to each course's table
            this.courseDtm.insertRow(course.courseTable.getRowCount(), new Object[]{
                this.name,
                this.studentNumber,
                course.prelimGrade.get(this.name),
                course.midtermGrade.get(this.name),
                course.finalsGrade.get(this.name),
                course.totalStanding.get(this.name)
            });
        }
        System.out.println(this.totalUnitsForGPA);
    }
    
    // Method to enroll a student to a course
    public void enrollToCourse(Course course) {
        this.enrolledCourses.add(course);
    }    
    
   // Method to update a student's GWA
    public void updateGwa(String studentName, Course course, char operation, Double standing) {
        if (course.includedInGPA) {
            switch (operation) {
                case '+' -> {
                    section.nameAndGwa.replace(studentName, 
                        section.nameAndGwa.get(studentName)
                       + (standing *(double)course.units)/(double)this.totalUnitsForGPA);
                }
                case '-' -> {
                    section.nameAndGwa.replace(studentName,
                        section.nameAndGwa.get(studentName)
                       - (standing *(double)course.units)/(double)this.totalUnitsForGPA);
                }
            }

        }
        
    }
    
}