
package com.mycompany.gradingsystem;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JTable;

/**
 *
 * Class containing the representation of Section
 */

public class Section {
    
    // Declaration of the ArrayList containing the courses the and students within the section
    ArrayList<Course> courseList;
    ArrayList<String> studentList;
    ArrayList<Integer> studentNumList;
    // Declaration of the name and gwaTable attribute of the section
    String name;
    JTable gwaTable;
    
    // Declaration of HashMaps containing studentName:studentGwa and studentName:studentObject
    HashMap<String, Double> nameAndGwa;
    HashMap<String, Student> nameAndObject;
    
    Section(String name, JTable gwaTable) {
        // Initialization of section attributes
        this.name = name;
        this.gwaTable = gwaTable;
        
        // Initialization of the lists of courses and students within a section
        this.courseList = new ArrayList<Course>();
        this.studentList = new ArrayList<String>();
        this.studentNumList = new ArrayList<Integer>() ;
        
        // Initialization of the HashMaps containing studentName:studentGwa and studentName:studentObject
        this.nameAndGwa = new HashMap<String, Double>();
        this.nameAndObject = new HashMap<String, Student>();
    }
    
    // Method to add a course to the section
    public void addCourse(Course course) {
        this.courseList.add(course);
    }
    
    // Method to add a student to the section
    public void addStudent(String student) {
        this.studentList.add(student);
    }
 
}
